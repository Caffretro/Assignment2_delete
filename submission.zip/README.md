## Logs
logs are stored in both notebook records and tensorboard

### Tensorboard Usage
tensorboard --logdir runs_LSTM\
tensorboard --logdir runs_transformer